
This is a heavily revised version of my (J. Zbiciak's) old "Bouncing 
Pixels" demo from 1999.  This version has been updated to assemble with 
as1600, to use library components for everything, and to operate correctly 
on a real Intellivision.

The library "Colored Squares" routines were originally developed as
part of this demo.  So, in a way, the routines have come full circle.
Cool, eh?

