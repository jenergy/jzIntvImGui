This is where any generated libraries will go.  This README is a placeholder
to ensure revision control systems create this directory.

