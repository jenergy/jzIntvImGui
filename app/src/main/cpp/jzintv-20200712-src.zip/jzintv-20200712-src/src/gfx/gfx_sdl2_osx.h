#ifndef GFX_SDL2_OSX_H_
#define GFX_SDL2_OSX_H_

bool gfx_set_srgb_colorspace(void *metal_layer);

#endif /* GFX_SDL2_OSX_H_ */
