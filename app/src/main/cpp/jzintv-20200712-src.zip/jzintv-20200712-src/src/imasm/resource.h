//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by imasm.rc
//
#define IDS_AUTO                        4
#define IDS_FILE_MENU                   7
#define IDS_FORMAT_MENU                 8
#define IDS_PROJECT_MENU                9
#define IDS_WINDOW_MENU                 10
#define IDS_HELP_MENU                   11
#define IDI_MAINICON                    101
#define IDC_MAINRICHED                  101
#define IDM_MAIN                        102
#define IDC_TOOLBAR                     102
#define IDC_AUTO                        103
#define IDB_AUTO                        103
#define UPDATETIMER                     104
#define IDC_STATUS                      106
#define IDD_ABOUT                       107
#define IDC_CHILDBASE                   107
#define IDR_ACCEL                       108
#define IDC_CLIENT                      108
#define IDB_PROJECT                     109
#define IDB_SOURCE                      110
#define IDD_NEWPROJECT                  110
#define IDB_INCLUDE                     111
#define IDB_FOLDER                      112
#define IDB_PROJECT1                    113
#define IDB_FOLDER1                     114
#define IDB_INCLUDE1                    115
#define IDB_SOURCE1                     116
#define IDB_OTHER1                      117
#define IDB_OTHER                       118
#define IDS_VERSION                     1000
#define IDC_PROJECTNAME                 1001
#define IDC_PROJECTPATH                 1002
#define IDC_BROWSE                      1003
#define IDC_NEW                         4001
#define IDC_OPEN                        4002
#define IDC_SAVE                        4003
#define IDC_SAVEAS                      4004
#define IDC_EXIT                        4005
#define IDC_OPENPROJECT                 4006
#define IDS_NEW                         4008
#define IDS_OPEN                        4009
#define IDS_SAVE                        4010
#define IDS_SAVEAS                      4011
#define IDS_EXIT                        4012
#define IDS_OPENPROJECT                 4013
#define IDC_FONT                        5000
#define IDC_PRECOMPILE                  5001
#define IDS_FONT                        5008
#define IDS_PRECOMPILE                  5009
#define IDC_ABOUT                       6000
#define IDS_ABOUT                       6011
#define IDC_CASCADE                     7000
#define IDC_TILEHORIZ                   7001
#define IDC_TILEVERT                    7002
#define IDS_CASCADE                     7010
#define IDS_TILEHORIZ                   7011
#define IDS_TILEVERT                    7012
#define IDC_PROJECTADD                  40014
#define IDC_PROJECTADDSOURCE            40014
#define IDC_PROJECTREMOVE               40015
#define IDC_PROJECTNEW                  40016
#define IDC_PROJECTADDINCLUDE           40019
#define IDC_PROJECTADDOTHER             40020

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40021
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
