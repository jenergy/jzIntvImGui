/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
cp1600_ins_t *const fn_dir_2op[] =
{
/*000*/  fn_invalid,
/*001*/  fn_MVO_dr,
/*010*/  fn_MVI_dr,
/*011*/  fn_ADD_dr,
/*100*/  fn_SUB_dr,
/*101*/  fn_CMP_dr,
/*110*/  fn_AND_dr,
/*111*/  fn_XOR_dr,
};
