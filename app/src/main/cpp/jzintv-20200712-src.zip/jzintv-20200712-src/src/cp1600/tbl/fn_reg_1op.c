/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
cp1600_ins_t *const fn_reg_1op[] =
{
/*000*/  fn_invalid,
/*001*/  fn_INCR_r,
/*010*/  fn_DECR_r,
/*011*/  fn_COMR_r,
/*100*/  fn_NEGR_r,
/*101*/  fn_ADCR_r,
/*110*/  fn_invalid,
/*111*/  fn_RSWD_r,
};
