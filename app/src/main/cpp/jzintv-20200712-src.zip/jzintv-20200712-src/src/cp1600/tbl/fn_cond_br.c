/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
cp1600_ins_t *const fn_cond_br[] =
{
/*00000*/    fn_B_i,
/*00001*/    fn_BC_i,
/*00010*/    fn_BOV_i,
/*00011*/    fn_BPL_i,
/*00100*/    fn_BEQ_i,
/*00101*/    fn_BLT_i,
/*00110*/    fn_BLE_i,
/*00111*/    fn_BUSC_i,
/*01000*/    fn_NOPP_i,
/*01001*/    fn_BNC_i,
/*01010*/    fn_BNOV_i,
/*01011*/    fn_BMI_i,
/*01100*/    fn_BNEQ_i,
/*01101*/    fn_BGE_i,
/*01110*/    fn_BGT_i,
/*01111*/    fn_BESC_i,
/*10000*/    fn_BEXT_i,
/*10001*/    fn_BEXT_i,
/*10010*/    fn_BEXT_i,
/*10011*/    fn_BEXT_i,
/*10100*/    fn_BEXT_i,
/*10101*/    fn_BEXT_i,
/*10110*/    fn_BEXT_i,
/*10111*/    fn_BEXT_i,
/*11000*/    fn_BEXT_i,
/*11001*/    fn_BEXT_i,
/*11010*/    fn_BEXT_i,
/*11011*/    fn_BEXT_i,
/*11100*/    fn_BEXT_i,
/*11101*/    fn_BEXT_i,
/*11110*/    fn_BEXT_i,
/*11111*/    fn_BEXT_i,
};

