/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
cp1600_ins_t *const fn_imm_2op[] =
{
/*0000*/     fn_invalid,
/*0001*/     fn_MVO_ir,
/*0010*/     fn_MVI_ir,
/*0011*/     fn_ADD_ir,
/*0100*/     fn_SUB_ir,
/*0101*/     fn_CMP_ir,
/*0110*/     fn_AND_ir,
/*0111*/     fn_XOR_ir,
/*1000*/     fn_invalid,
/*1001*/     fn_MVO_Ir,
/*1010*/     fn_MVI_Ir,
/*1011*/     fn_ADD_Ir,
/*1100*/     fn_SUB_Ir,
/*1101*/     fn_CMP_Ir,
/*1110*/     fn_AND_Ir,
/*1111*/     fn_XOR_Ir,
};
