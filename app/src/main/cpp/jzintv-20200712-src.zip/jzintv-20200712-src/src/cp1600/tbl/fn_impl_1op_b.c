/* Auto generated, do not edit */

#include "cp1600/op_tables.h"
cp1600_ins_t *const fn_impl_1op_b[] =
{
/*00*/   fn_invalid,
/*01*/   fn_TCI,
/*10*/   fn_CLRC,
/*11*/   fn_SETC,
};
