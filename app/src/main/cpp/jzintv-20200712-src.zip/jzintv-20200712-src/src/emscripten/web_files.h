#ifndef LZOE_WEB_FILES
#define LZOE_WEB_FILES 1

#include "lzoe/lzoe.h"

extern const lzoe_info lzoe_web_files[6];
#endif
