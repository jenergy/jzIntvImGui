#ifndef TYPETAGS_H_
#define TYPETAGS_H_

#define TYPE_CODE   (0x10)
#define TYPE_DATA   (0x20)
#define TYPE_DBDATA (0x40)
#define TYPE_STRING (0x80)
#define TYPE_HOLE   (0x00)

#endif
